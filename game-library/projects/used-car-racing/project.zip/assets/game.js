/* Native-room input, race UI and lifecycle. Vehicle physics remains in game-model.js. */
(function(root){'use strict';
  var $=function(id){return document.getElementById(id);},M=root.UsedCarModel,T=root.UsedCarTracks,bridge=root.UsedCarHost,game=null,renderer=null,sound=null,info={language:'zh',url:'',qr:''},english=false,keys={},pulses={},keyUsers=[false,false],phoneSlots=[1,2],lastButtons=[0,1,2,3].map(function(){return {start:false,select:false,startSeq:0,selectSeq:0,cancelSeq:null};}),selectAt=[0,0,0,0],selectUsed=[false,false,false,false],reverse=[false,false],participatingPhones=[false,false],armed=[true,true],localCancel=0,latest=[],frame=0,lastTime=0,lastDraw=0,lastUi=0,lastPublish=0,lastEvent=0,messageUntil=0,navAt=0,roomTimer=0,disposed=false,suspended=false,visible=!document.hidden,renderFailed=false,contextLost=false,pauseReason='',manualPlayers=false,cameraMode='chase',cardRevision='',hudCount=0,muted=false,previousPhase='';
  function tr(zh,en){return english?en:zh;}
  function name(value){return Array.isArray(value)?value[english?1:0]:String(value||'');}
  function set(id,value){var node=$(id);if(node&&node.textContent!==String(value))node.textContent=value;}
  function escape(value){return String(value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function number(v){return Math.round(Number(v)||0);}
  function time(value){value=Math.max(0,Number(value)||0);var m=Math.floor(value/60),s=Math.floor(value%60),ms=Math.floor(value*1000)%1000;return (m<10?'0':'')+m+':'+(s<10?'0':'')+s+'.'+('00'+ms).slice(-3);}
  function safeUnlock(){if(sound)sound.unlock().catch(function(){});}
  try{if(bridge)info=JSON.parse(bridge.getInfo());}catch(_){}
  english=String(info.language).indexOf('en')===0;document.documentElement.lang=english?'en':'zh-CN';
  var labels={
    'inspection-heading':['二手车锦标赛','THE SECOND-HAND CHAMPIONSHIP'],
    'race-track-label':['赛道','CIRCUIT'],
    'pause-kicker':['进站休整','PIT STOP'],
    'results-kicker':['成功完赛','YOU MADE IT.'],
    'brand-title':['极品二手车','USED CAR'],
    'author-line':['桔子桑原创','ORIGINAL / ECOJUST'],

    'brand-subtitle':['不完美的车。真正的驾驶。','IMPERFECT CARS. REAL CONSEQUENCES.'],'intro-detail':['六辆车，同一条起跑线。驾驶你的不完美。','Six cars. One starting line. Drive your imperfections.'],
    'session-label':['车况已揭晓','VEHICLE INSPECTION COMPLETE'],'phone-label':['手机即手柄','YOUR PHONE. YOUR WHEEL.'],'steer-help':['左侧渐进转向','Progressive steering on left'],'pedal-help':['右上油门 · 右下刹车','Top: throttle / Bottom: brake'],'start-help':['开始 / 暂停','Start / pause'],'select-help':['短按镜头 · 低速长按换挡','Tap: camera / Hold: D–R'],
    'draw-note':['每场随机车辆与车况','Random cars. Real compromises.'],'circuit-label':['选择赛道','CHOOSE CIRCUIT'],'start-label':['驶上起跑线','TAKE THE GRID'],'reroll':['↻ 重新抽车','↻ DRAW ANOTHER CAR'],'pause-button':['暂停','PAUSE'],'resume':['继续比赛 ↗','BACK TO THE RACE ↗'],'recover':['拖车复位','RECOVER CAR'],'back-garage':['返回车库','BACK TO GARAGE'],'new-race':['下一场，换一种命运 ↗','ANOTHER RACE. ANOTHER CHANCE. ↗'],'results-title':['旧车，也有好成绩。','OLD CARS. NEW STORIES.'],
    'footer-hint':['方向键选赛道 · 确定 / START 开始 · SELECT 抽车','Arrows: circuit / Enter or START: race / SELECT: draw'],'startup-title':['正在点火…','TURNING THE KEY…'],'startup-detail':['准备车辆、赛道和局域网手柄','Preparing cars, circuits and phone controllers']
  };
  Object.keys(labels).forEach(function(id){set(id,name(labels[id]));});
  $('game-title').innerHTML=english?'USED CARS.<span>UNEXPECTED STORIES.</span>':'极品二手车<span>好坏，全凭手气。</span>';
  $('room-help').innerHTML=english?'Same Wi-Fi as the TV.<br>Scan to join. No app needed.':'手机和电视连接同一 Wi-Fi<br>扫描二维码，直接加入';
  $('road').setAttribute('aria-label',tr('三维赛车画面','3D racing scene'));$('minimap').setAttribute('aria-label',tr('赛道小地图','Circuit map'));$('room-qr').alt=tr('手机连接二维码','Phone controller QR code');
      var lastWifiRefresh = -1000;
    function updateWifi(refresh) {
      if (refresh && performance.now() - lastWifiRefresh >= 500) {
        lastWifiRefresh = performance.now();
        try { if (bridge) info = Object.assign({}, info, JSON.parse(bridge.getInfo())); } catch (_) {}
      }
      var wifi = info.wifiController || {}, address = (wifi.addresses || []).filter(function(v){return typeof v === 'string';}).join(' / ');
      var node = document.getElementById('puretv-address');
      if (!node) return;
      node.textContent = wifi.port > 0 && address ? address + ':' + wifi.port : tr('等待局域网地址', 'Waiting for LAN address');
      document.getElementById('puretv-status').textContent = (wifi.state === 'unavailable' ? (wifi.port > 0 ? tr('自动发现暂不可用，可按地址直连', 'Discovery unavailable; connect by address') : tr('手柄服务暂不可用，请重新打开游戏', 'Controller service unavailable; reopen game')) : wifi.connected ? tr('已连接 · START 开始 / 暂停', 'Connected · START begin / pause') : wifi.state === 'available' ? tr('同一网络，按手柄搜索键连接', 'Same network: press controller Search') : tr('正在准备手柄服务', 'Preparing controller service'));
      document.getElementById('puretv-help').textContent = tr('左右转向 · A/X 油门 · B 刹车 · Y 镜头/换挡', 'Steer · A/X throttle · B brake · Y camera/gear');
    }
    function updateRoom(value){
    if(disposed)return;info=Object.assign({},info,value||{});updateWifi();
    var ready=!!(info.url&&info.qr),fingerprint=String(info.certificateFingerprint||''),secure=!!(ready&&info.secureUrl&&info.secureQr&&/^[a-f0-9]{64}$/i.test(fingerprint));
    $('room').dataset.secure=String(secure);$('room').dataset.securityError=String(!!info.secureError);
    $('room-qr').hidden=!ready;$('room-pending').hidden=ready;
    if(ready){if($('room-qr').src!==info.qr)$('room-qr').src=info.qr;set('room-address',String(info.url).split('?')[0]);}
    else{set('room-address','');set('room-pending',info.error||tr('连接局域网后打开游戏','Open the game on a local network'));}
    $('room-setup-label').hidden=!secure;$('room-secure-code').hidden=!secure;$('room-certificate').hidden=!secure;
    set('room-setup-label',tr('首次连接','First connection'));set('room-secure-label',tr('已信任证书','Certificate trusted'));set('room-certificate-label',tr('核对电视证书','Check TV certificate'));
    $('room-help').innerHTML=secure?tr('同一 Wi-Fi · 首次按手机引导<br>已信任证书可直接进入手柄','Same Wi-Fi · Follow phone setup<br>Already trusted? Scan the right code.'):tr('手机和电视连接同一 Wi-Fi<br>扫描二维码，直接加入','Same Wi-Fi as the TV.<br>Scan to join. No app needed.');
    if(secure){
      if($('room-secure-qr').src!==info.secureQr)$('room-secure-qr').src=info.secureQr;
      $('room-secure-qr').alt=tr('已信任证书的安全手柄二维码','Secure controller QR for phones that trust this TV');
      set('room-secure-address',String(info.secureUrl).split('?')[0]);set('room-certificate-name',info.certificateName||'pureTV');
      var groups=fingerprint.toUpperCase().match(/.{4}/g),lines=[];for(var i=0;i<groups.length;i+=4)lines.push(groups.slice(i,i+4).join(' '));
      set('room-certificate-fingerprint',lines.join('\n'));
    }else{set('room-secure-address','');set('room-certificate-name','');set('room-certificate-fingerprint','');}
    $('room-security-error').hidden=!info.secureError;set('room-security-error',info.secureError||'');
  }
  function trackName(track){return english?track.enName:track.name;}
  function outline(track){var b=track.bounds,w=b.maxX-b.minX,h=b.maxZ-b.minZ,scale=Math.min(42/w,32/h),path='';for(var i=0;i<track.points.length;i+=8){var p=track.points[i];path+=(i?'L':'M')+((p.x-b.minX)*scale+(47-w*scale)/2).toFixed(1)+','+((p.z-b.minZ)*scale+(38-h*scale)/2).toFixed(1);}return path+'Z';}
  function menu(){if(!game)return;var signature=game.playerCount+':'+game.trackId+':'+game.players.map(function(c){return c.spec.id+':'+c.condition.fault.id+':'+c.condition.mileage;}).join('/');if(signature===cardRevision)return;cardRevision=signature;
    $('vehicle-cards').innerHTML=game.players.map(function(c,i){var s=c.spec,f=c.condition;return '<article class="vehicle-card p'+(i+1)+'"><div class="lot-row"><b>'+(i+1)+'P</b><span>'+tr('车况档案','INSPECTION')+' / '+s.year+'</span></div><h2>'+escape(name(s.name))+'</h2><div class="vehicle-history">'+f.mileage.toLocaleString(english?'en-US':'zh-CN')+' KM · '+s.drive+' · '+tr('自动变速箱','AUTOMATIC')+'</div><div class="spec-grid"><div><strong>'+s.powerKw+'</strong><small>kW '+tr('功率','POWER')+'</small></div><div><strong>'+s.peakTorque+'</strong><small>N·m '+tr('扭矩','TORQUE')+'</small></div><div><strong>'+s.mass+'</strong><small>kg '+tr('车重','MASS')+'</small></div></div><div class="fault-box"><b>⚠ '+escape(name(f.fault.name))+'</b><p>'+escape(name(f.fault.description))+'</p></div></article>';}).join('');
    var options=$('track-options');options.innerHTML=T.all.map(function(t,i){return '<button class="track-option '+(t.id===game.trackId?'selected':'')+'" data-track="'+t.id+'" aria-pressed="'+(t.id===game.trackId)+'"><svg viewBox="0 0 47 38" aria-hidden="true"><path d="'+outline(t)+'"/></svg><span><strong>'+escape(trackName(t))+'</strong><small>0'+(i+1)+' / '+(t.length/1000).toFixed(2)+' KM · '+tr('3 圈','3 LAPS')+'</small></span></button>';}).join('');
    Array.prototype.forEach.call(document.querySelectorAll('[data-players]'),function(button){button.classList.toggle('selected',Number(button.dataset.players)===game.playerCount);});set('ai-label','+ '+(game.totalCars-game.playerCount)+tr(' 名电脑车手',' AI'));$('app').dataset.players=String(game.playerCount);
  }
  function notice(zh,en){set('race-message',tr(zh,en));$('race-message').hidden=false;messageUntil=performance.now()+3300;}
  root.PureTVQA = {snapshot: function () {
      var players = game && game.players ? game.players.map(function(player) {
        var copy = {};
        ['id','x','y','z','yaw','angle','facing','speed','movingSpeed','lateral','s','u','v','steerAngle','driftTime','drifting','driftCharge','boost','item','heldItem','inventory','tool','netRaised','weapon','ammo','grenades','fireCooldown','previous','lap','rank','connected','joined','active','cancelSeq','telemetry'].forEach(function(key){if (player[key] !== undefined) copy[key] = player[key];});
        return copy;
      }) : [];
      var model = {phase: game ? game.phase : 'loading', players: players};
      ['elapsed','raceTime','clock','countdown','stage','trackIndex','trackId','selectedPlayers','playerCount','kills','credits','eventSerial','events','projectiles','bullets'].forEach(function(key){if(game && game[key] !== undefined) model[key] = game[key];});
      var camera = renderer && renderer.camera;
      return JSON.parse(JSON.stringify({phase:model.phase,paused:!!(suspended || !visible || model.phase === 'paused'),controllerPaused:!!(game && model.phase === 'paused'),controllers:controllerAdapter.peek(),info:info,model:model,players:players,camera:camera && camera.matrixWorldInverse ? {projection:camera.projectionMatrix.elements,view:camera.matrixWorldInverse.elements} : null}));
    }};
    var controllerInputs = [], controllerAdapter = root.PureTVControllerAdapter.create({onCancel: function (event) { if (game && phoneSlots.indexOf(event.id) >= game.playerCount) return false; if (!game || ["race", "countdown", "paused"].indexOf(game.phase) < 0) return false;
        pause("controller"); return true; }});
    function getInputs(){var raw=[];try{if(bridge)raw=JSON.parse(bridge.snapshot()).players||[];}catch(_){}raw=controllerAdapter.read(raw);controllerInputs=raw;var slots=[0,1].map(function(i){var entry=raw.filter(function(v){return v&&Number(v.id)===i+1;})[0],p=entry||{},connected=!!p.connected;return {id:i+1,available:!!entry,transport:p.transport,session:p.session,connected:connected,x:connected?Math.max(-1,Math.min(1,Number(p.x)||0)):0,y:connected?Math.max(-1,Math.min(1,Number(p.y)||0)):0,a:connected&&!!p.a,b:connected&&!!p.b,phoneStart:connected&&!!p.start,phoneSelect:connected&&!!p.select,hasStartSeq:typeof p.startSeq==='number',hasSelectSeq:typeof p.selectSeq==='number',startSeq:Number(p.startSeq)||0,selectSeq:Number(p.selectSeq)||0,selectMs:typeof p.selectMs==='number'?Math.max(0,p.selectMs):null,cancelSeq:Number(p.cancelSeq)||0};});
    // Fill logical driving seats from the phones present in the garage. A race
    // keeps this assignment so a late arrival cannot replace a disconnected driver.
    if(!game||game.phase==='garage'){phoneSlots=slots.filter(function(p){return p.connected;}).concat(slots.filter(function(p){return !p.connected;})).map(function(p){return p.id;});}
    var current=phoneSlots.map(function(id){return slots[id-1];}),now=performance.now();
    current[0].x=(keys.ArrowRight?1:0)-(keys.ArrowLeft?1:0)||current[0].x;current[0].a=current[0].a||!!keys.z||!!keys.ArrowUp;current[0].b=current[0].b||!!keys.x||!!keys.b||!!keys.ArrowDown;current[0].keyStart=!!keys.Enter||!!keys.Start||!!keys.p||!!pulses.start;current[0].keySelect=!!keys.Shift||!!keys.Select||!!pulses.select;
    current[1].x=(keys.d?1:0)-(keys.a?1:0)||current[1].x;current[1].a=current[1].a||!!keys.w;current[1].b=current[1].b||!!keys.s;current[1].keyStart=!!keys.Tab||!!pulses.start2;current[1].keySelect=!!keys.q||!!pulses.select2;
    current.forEach(function(p){p.start=p.phoneStart||p.keyStart;p.select=p.phoneSelect||p.keySelect;});return current;
  }
  function syncPlayerCount(current){if(game&&game.phase==='garage'&&!manualPlayers){var count=Math.max(1,current.filter(function(p){return p.connected;}).length);if(count!==game.playerCount){M.setPlayers(game,count);cardRevision='';menu();}}}
  function release(){keys={};pulses={};selectUsed=[true,true,true,true];localCancel++;if(game)M.releaseControls(game);armed=[false,false];}
  var backgroundResumeRequested = false;
  function requestBackgroundResume() {
    backgroundResumeRequested = visible && !suspended && pauseReason === 'background';
  }
  function hasMissingPhone(){return participatingPhones.some(function(was,i){return i<game.playerCount&&was&&!(latest[i]&&latest[i].connected);});}
  function pause(reason){backgroundResumeRequested=false;if(!game)return;if(M.pause(game))pauseReason=reason||'manual';release();if(sound)sound.pause(true);}
  function resume(){if(!game||game.phase!=='paused')return;if(hasMissingPhone()||suspended||!visible||contextLost)return;M.resume(game);pauseReason='';backgroundResumeRequested=false;release();lastTime=0;safeUnlock();}
  function begin(){if(!game||renderFailed||contextLost)return;if(game.phase==='paused'){resume();return;}if(game.phase==='results'){garage();return;}if(game.phase!=='garage'){pause('manual');return;}syncPlayerCount(latest);if(game.playerCount===2&&!(latest[1].connected||keyUsers[1]||!bridge)){set('draw-note',tr('请先连接第二部手机手柄','Connect a second phone controller first'));return;}participatingPhones=latest.map(function(p,i){return i<game.playerCount&&p.connected;});reverse=[false,false];armed=[true,true];lastEvent=0;if(sound)sound.lastEvent=0;M.start(game);pauseReason='';safeUnlock();renderUi(performance.now());}
  function garage(){if(!game)return;M.reset(game);hudCount=0;pauseReason='';reverse=[false,false];armed=[true,true];participatingPhones=[false,false];cardRevision='';lastEvent=0;if(sound)sound.lastEvent=0;syncPlayerCount(latest);menu();renderUi(performance.now());}
  function draw(){if(game&&game.phase==='garage'){M.reroll(game);cardRevision='';menu();safeUnlock();}}
  function changeCamera(){cameraMode=cameraMode==='chase'?'hood':'chase';if(renderer)renderer.setCamera(cameraMode);set('camera-button',cameraMode==='chase'?tr('追车镜头','CHASE CAM'):tr('引擎盖镜头','HOOD CAM'));}
  function changeGear(i){var car=game&&game.players[i];if(!car||game.phase!=='race')return;if(Math.abs(car.speed)>1.2){notice('减速至接近静止后换挡','Slow nearly to a stop before changing D / R');return;}reverse[i]=!reverse[i];notice((i+1)+'P · '+(reverse[i]?'倒车挡 R':'前进挡 D'),(i+1)+'P · '+(reverse[i]?'REVERSE R':'DRIVE D'));}
  function handle(current,now){if(!game)return;syncPlayerCount(current);
    // Menu gestures belong to physical sources, not driving seats: swapping a
    // garage seat must not turn a held button into another START or SELECT press.
    var signals=[];current.forEach(function(p,i){signals.push({available:p.available,player:i,source:p.id-1,start:p.phoneStart,select:p.phoneSelect,hasStartSeq:p.hasStartSeq,hasSelectSeq:p.hasSelectSeq,startSeq:p.startSeq,selectSeq:p.selectSeq,selectMs:p.selectMs,cancelSeq:p.cancelSeq});signals.push({available:true,player:i,source:i+2,start:p.keyStart,select:p.keySelect,startSeq:0,selectSeq:0,selectMs:null,cancelSeq:0});});
    // Cancellation and a new heartbeat may land between two TV frames. Consume
    // the current menu state until release instead of replaying the old gesture.
    var startEdge=!!pulses.start||(game.playerCount>1&&!!pulses.start2);signals.forEach(function(p){if(!p.available){selectUsed[p.source]=true;return;}var old=lastButtons[p.source];if(old.cancelSeq!==null&&old.cancelSeq!==p.cancelSeq){old.start=p.start;old.select=p.select;if(p.hasStartSeq)old.startSeq=p.startSeq;if(p.hasSelectSeq)old.selectSeq=p.selectSeq;selectAt[p.source]=now;selectUsed[p.source]=true;}old.cancelSeq=p.cancelSeq;if(p.player<game.playerCount&&(p.hasStartSeq?p.startSeq>old.startSeq:(p.start&&!old.start)))startEdge=true;});
    if(startEdge)begin();var menuSelect=false,cameraRequested=false,gearRequested=[false,false];signals.forEach(function(p){if(!p.available)return;var slot=p.source,old=lastButtons[slot],selectEdge=p.hasSelectSeq?p.selectSeq>old.selectSeq:(p.select&&!old.select);if(p.player<game.playerCount){
      if(selectEdge){selectAt[slot]=now-(p.selectMs===null?0:p.selectMs);selectUsed[slot]=false;if(game.phase==='garage'){if(!menuSelect)draw();menuSelect=true;selectUsed[slot]=true;}else if(game.phase==='results'){if(!menuSelect)garage();menuSelect=true;selectUsed[slot]=true;}}
      if((p.select||old.select||selectEdge)&&!selectUsed[slot]&&game.phase==='race'&&(p.selectMs===null?now-selectAt[slot]:p.selectMs)>=800){if(!gearRequested[p.player])changeGear(p.player);gearRequested[p.player]=true;selectUsed[slot]=true;}
      if(!p.select&&(old.select||selectEdge)&&!selectUsed[slot]&&game.phase==='race'){cameraRequested=true;selectUsed[slot]=true;}
    }else selectUsed[slot]=true;old.start=p.start;old.select=p.select;if(p.hasStartSeq)old.startSeq=p.startSeq;if(p.hasSelectSeq)old.selectSeq=p.selectSeq;});
    current.forEach(function(p,i){if(game.phase!=='garage'&&game.phase!=='results'&&i<game.playerCount&&p.connected)participatingPhones[i]=true;});
    pulses={};if(cameraRequested)changeCamera();if(game.phase==='garage'&&Math.abs(current[0].x)>.65&&now>navAt){var index=T.all.indexOf(game.track);M.setTrack(game,(index+(current[0].x>0?1:-1)+T.all.length)%T.all.length);navAt=now+450;cardRevision='';menu();}else if(Math.abs(current[0].x)<.3)navAt=0;
    // The host may still have reported an empty room while the app was suspended.
    // Use this frame's room sample before resuming a returning phone driver.
    if ((game.phase === 'race' || game.phase === 'countdown') && hasMissingPhone()) {
      pause('disconnect');
    } else if (game.phase === 'paused' && (pauseReason === 'disconnect' || backgroundResumeRequested)
        && !hasMissingPhone() && !controllerInputs.some(function (p) { return p.transport === 'wifi'; })) {
      resume();
    }
  }
  function controls(current){return current.slice(0,game.playerCount).map(function(p,i){var neutral=!p.a&&!p.b&&Math.abs(p.x)<.08;if(neutral)armed[i]=true;
    // Phone stick, clockwise phone tilt and keyboard right all send +x.
    // Looking forward along +Z, camera-right is -X, opposite positive model yaw.
    // Convert only human controls; AI already computes geometric wheel angles.
    // A progressive center gives fine lane corrections without losing full lock.
    var steering=-p.x*(.45+.55*p.x*p.x);
    return {steer:armed[i]?steering:0,throttle:armed[i]&&p.a?1:0,brake:armed[i]&&p.b?1:0,reverse:reverse[i],handbrake:false,cancelSeq:p.cancelSeq+localCancel*1000000};});}
  function driverPanels(){if(hudCount===game.playerCount)return;hudCount=game.playerCount;$('driver-huds').innerHTML=game.players.map(function(c,i){return '<section class="driver-hud p'+(i+1)+'" id="driver-'+i+'"><div class="speed-block"><div class="driver-label">'+(i+1)+'P · <span id="position-'+i+'">1 / 6</span> · <span id="lap-'+i+'">1 / 3</span></div><div class="speed-line"><strong class="speed" id="speed-'+i+'">0</strong><small class="speed-unit">KM/H</small><strong class="gear" id="gear-'+i+'">1</strong></div><div class="rpm-bar"><i id="rpm-fill-'+i+'"></i></div><div class="rpm-line"><span id="rpm-'+i+'">850 RPM</span><span>'+c.spec.redline+'</span></div><div class="driver-alert" id="driver-alert-'+i+'"></div></div><div class="telemetry"><div class="telemetry-title"><span>'+tr('踏板力','PEDAL FORCE')+'</span><span id="abs-'+i+'">ABS</span></div><div class="pedal-number"><span id="pedal-'+i+'">0</span><small id="pedal-unit-'+i+'">N</small></div><div class="pedal-bar"><i id="pedal-fill-'+i+'"></i></div><div class="telemetry-stats"><span id="heat-'+i+'">28°C</span><span id="grip-'+i+'">μ 0.90</span></div></div></section>';}).join('');}
  function minimap(){var ctx=$('minimap').getContext('2d'),track=game.track,b=track.bounds,w=b.maxX-b.minX,h=b.maxZ-b.minZ,scale=Math.min(212/w,132/h),ox=(240-w*scale)/2,oy=(160-h*scale)/2;ctx.clearRect(0,0,240,160);ctx.beginPath();track.points.forEach(function(p,i){var x=ox+(p.x-b.minX)*scale,y=oy+(p.z-b.minZ)*scale;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);});ctx.closePath();ctx.lineWidth=5;ctx.strokeStyle='#05131bd9';ctx.stroke();ctx.lineWidth=2;ctx.strokeStyle='#a4b9bb';ctx.stroke();game.racers.forEach(function(c){ctx.fillStyle=c.human?(c.playerIndex===0?'#d4f95c':'#67d7ee'):'#697983';ctx.beginPath();ctx.arc(ox+(c.x-b.minX)*scale,oy+(c.z-b.minZ)*scale,c.human?4:2.2,0,Math.PI*2);ctx.fill();});}
  function renderUi(now){if(!game)return;updateWifi(true);root.PureTVControllerAdapter.renderClients($('controller-clients'),controllerAdapter.peek(),{language:english?'en':'zh',showPhones:true});var phase=game.phase,garageOpen=phase==='garage';$('app').dataset.phase=phase;$('app').dataset.players=String(game.playerCount);$('garage').hidden=!garageOpen;$('room').hidden=!(garageOpen||phase==='paused');$('race-hud').hidden=garageOpen||phase==='results';$('pause-panel').hidden=phase!=='paused';$('results').hidden=phase!=='results';$('countdown').hidden=phase!=='countdown';if(phase==='countdown')set('countdown',Math.max(1,Math.ceil(game.countdown)));
    if(garageOpen)menu();set('session-label',garageOpen?tr('车况已揭晓','VEHICLE INSPECTION COMPLETE'):phase==='paused'?tr('赛道暂停','RACE PAUSED'):tr('六车竞速','SIX-CAR CHAMPIONSHIP'));
    latest.forEach(function(p,i){$('room-player-'+(i+1)).classList.toggle('connected',p.connected);set('room-status-'+(i+1),p.connected?tr('已连接 · 准备就绪','CONNECTED / READY'):keyUsers[i]?tr('遥控器 / 键盘','REMOTE / KEYBOARD'):tr('等待连接','WAITING TO JOIN'));});
    set('sound-button',tr('声音 ','SOUND ')+(muted?tr('关','OFF'):tr('开','ON')));set('race-track',trackName(game.track));set('race-time',time(game.raceTime));set('race-format',game.totalCars+tr(' 辆赛车 / ',' CARS / ')+game.laps+tr(' 圈',' LAPS'));
    if(!garageOpen){driverPanels();game.players.forEach(function(c,i){var t=c.telemetry,broken=c.condition.brakeBroken,warning=c.condition.weakPedal&&!broken&&t.pedalForceN>=1250;set('speed-'+i,number(t.speedKmh));set('gear-'+i,t.gear<0?'R':t.gear);set('rpm-'+i,number(t.rpm)+' RPM');$('rpm-fill-'+i).style.width=Math.min(100,t.rpm/c.spec.redline*100)+'%';set('position-'+i,c.rank+' / '+game.totalCars);set('lap-'+i,tr('圈 ','LAP ')+c.lap+' / '+game.laps);set('pedal-'+i,broken?tr('断裂','BROKEN'):number(t.pedalForceN));set('pedal-unit-'+i,broken?'':(c.condition.weakPedal?'/ 1600 N':'N'));$('pedal-fill-'+i).style.width=Math.min(100,t.pedalForceN/1800*100)+'%';$('driver-'+i).classList.toggle('warning',warning);$('driver-'+i).classList.toggle('broken',broken);set('abs-'+i,t.absActive?'ABS ●':c.condition.absAvailable?'ABS':tr('无 ABS','NO ABS'));set('heat-'+i,number(t.brakeTemp)+'°C');set('grip-'+i,'μ '+(Number(t.grip)||0).toFixed(2));set('driver-alert-'+i,broken?tr('制动失效 · 松油滑行减速','BRAKES LOST / LIFT TO SLOW'):warning?tr('接近 1600 N · 松开刹车！','APPROACHING 1600 N / RELEASE!'):t.locked?tr('轮胎抱死','TIRES LOCKED'):t.offRoad?tr('路肩 · 抓地力降低','SHOULDER / LOW GRIP'):name(c.spec.name));});
      $('leaderboard').innerHTML=game.racers.slice().sort(function(a,b){return a.rank-b.rank;}).map(function(c){return '<div class="rank-row '+(c.human?'human':'')+'"><b>'+c.rank+'</b><span>'+escape(c.human?(c.playerIndex+1)+'P':name(c.spec.name))+'</span><em>'+(c.finished?'✓':c.human?tr('玩家','YOU'):tr('电脑','AI'))+'</em></div>';}).join('');minimap();
    }
    if(phase==='paused'){set('pause-title',pauseReason==='disconnect'?tr('手柄已断开','CONTROLLER DISCONNECTED'):pauseReason==='graphics'?tr('图形正在恢复','RESTORING GRAPHICS'):tr('比赛暂停','RACE PAUSED'));set('pause-detail',pauseReason==='disconnect'?tr('重新连接参与比赛的手机，比赛将自动继续。','Reconnect the participating phone to continue automatically.'):pauseReason==='graphics'?tr('等待三维画面恢复后继续。','Waiting for the 3D scene to recover.'):tr('松开踏板再继续。拖车复位会罚退 12 米，不会修复已断裂的刹车。','Release the pedals before resuming. Recovery costs 12 m and does not repair broken brakes.'));$('resume').disabled=hasMissingPhone()||contextLost;}
    if(phase==='results'&&previousPhase!=='results'){$('result-list').innerHTML=game.players.map(function(c){return '<div class="result-row"><b>#'+c.rank+'</b><div><span>'+(c.playerIndex+1)+'P · '+escape(name(c.spec.name))+'</span><small>'+escape(name(c.condition.fault.name))+'</small></div><time>'+time(c.finishTime)+'</time></div>';}).join('');try{var records=JSON.parse(localStorage.getItem('used-car-best-times')||'{}');game.players.forEach(function(c){if(c.finishTime&&(!records[game.trackId]||c.finishTime<records[game.trackId]))records[game.trackId]=c.finishTime;});localStorage.setItem('used-car-best-times',JSON.stringify(records));}catch(_){}}
    game.events.forEach(function(e){if(e.id<=lastEvent)return;lastEvent=e.id;if(e.kind==='pedal-break'&&e.playerIndex!==null)notice((e.playerIndex+1)+'P · '+e.text[0],(e.playerIndex+1)+'P · '+e.text[1]);});if(now>messageUntil)$('race-message').hidden=true;previousPhase=phase;
    set('footer-hint',garageOpen?tr('方向键选赛道 · 确定 / START 开始 · SELECT 抽车','Arrows: circuit / Enter or START: race / SELECT: draw'):tr('A 油门 · B 按住刹车蓄力 · SELECT 短按镜头 / 低速长按换挡','A throttle / Hold B to brake / SELECT tap: camera, hold at low speed: D–R'));
  }
  function publish(){if(!bridge||!game||disposed)return;try{bridge.publish(JSON.stringify({game:'used-car-racing',phase:game.phase,trackName:game.track.name,trackNameEn:game.track.enName,laps:game.laps,selectedPlayers:game.playerCount,players:game.players.map(function(c){return {id:phoneSlots[c.playerIndex],driver:c.playerIndex+1,carName:c.spec.name[0],carNameEn:c.spec.name[1],speedKmh:number(c.telemetry.speedKmh),rpm:number(c.telemetry.rpm),gear:c.gear,brakeForce:number(c.telemetry.pedalForceN),brakeBroken:c.condition.brakeBroken,lap:c.lap,rank:c.rank};})}));}catch(_){} }
  function resize(){if(renderer&&!disposed)renderer.resize(Math.min(1600,Math.max(960,root.innerWidth)),Math.round(Math.min(1600,Math.max(960,root.innerWidth))*root.innerHeight/root.innerWidth));}
  function fail(error){renderFailed=true;pause('graphics');$('startup').hidden=false;$('startup').classList.add('failed');set('startup-title',tr('无法启动三维画面','3D GRAPHICS UNAVAILABLE'));set('startup-detail',tr('请确认电视支持 WebGL，并更新系统 WebView。游戏需要三维图形支持。','This game requires WebGL. Check TV graphics support and update the system WebView.'));if(root.console)console.error('Used Car Racing startup failed:',error&&error.message||error);}
  function animate(now){if(disposed||!visible)return;frame=root.requestAnimationFrame(animate);latest=getInputs();if(game){handle(latest,now);var dt=lastTime?Math.min(.25,(now-lastTime)/1000):0;lastTime=now;try{if(!suspended&&!contextLost&&!renderFailed)M.update(game,dt,controls(latest));if(renderer&&!suspended&&!contextLost&&!renderFailed&&now-lastDraw>=1000/30){var drawDt=lastDraw?Math.min(.1,(now-lastDraw)/1000):dt;lastDraw=now;if(!renderer.render(game,drawDt)){if(renderer.contextLost){contextLost=true;pause('graphics');}else throw new Error(renderer.error||'3D render failed');}}if(sound){if(latest.some(function(p){return p.start||p.a||p.b;}))safeUnlock();sound.muted=muted;sound.update(game);}}catch(error){fail(error);}}
    if(now-lastUi>80){renderUi(now);lastUi=now;}if(now-lastPublish>100){publish();lastPublish=now;}
  }
  function suspend(value){suspended=!!value;release();lastTime=0;if(suspended)pause('background');else requestBackgroundResume();publish();}
  function key(code,down){if(disposed)return;code=String(code);if(code.length===1)code=code.toLowerCase();var supported=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Enter','Start','Select','Shift','Tab','z','x','b','w','s','a','d','q','r','m','p','Escape',' '];if(supported.indexOf(code)<0)return;var was=!!keys[code];keys[code]=!!down;if(down){keyUsers[['w','s','a','d','q','Tab'].indexOf(code)>=0?1:0]=true;safeUnlock();if(!was){if(code==='r')changeGear(0);if(code==='m')toggleSound();if(code==='Escape'&&game&&game.phase==='race')pause('manual');if(code==='Enter'||code==='Start'||code==='p')pulses.start=true;if(code==='Shift'||code==='Select')pulses.select=true;if(code==='Tab')pulses.start2=true;if(code==='q')pulses.select2=true;if(code===' '&&game&&game.phase==='garage')draw();}}}
  function toggleSound(){muted=!muted;if(sound){sound.muted=muted;sound.pause(game&&game.phase==='paused');}try{localStorage.setItem('used-car-muted',String(muted));}catch(_){}safeUnlock();set('sound-button',tr('声音 ','SOUND ')+(muted?tr('关','OFF'):tr('开','ON')));}
  function dispose(){if(disposed)return;disposed=true;release();root.cancelAnimationFrame(frame);root.clearInterval(roomTimer);if(sound)sound.dispose();if(renderer)renderer.dispose();root.removeEventListener('resize',resize);}
  root.UsedCarTV={controllerSnapshot:function(){return controllerAdapter.peek();},key:key,updateRoom:updateRoom,suspend:suspend,dispose:dispose,start:begin,garage:garage,pause:function(){pause('manual');},resume:resume};Object.defineProperty(root.UsedCarTV,'game',{get:function(){return game;}});Object.defineProperty(root.UsedCarTV,'renderer',{get:function(){return renderer;}});
  $('start').onclick=begin;$('reroll').onclick=draw;$('pause-button').onclick=function(){pause('manual');};$('resume').onclick=resume;$('back-garage').onclick=garage;$('new-race').onclick=garage;$('sound-button').onclick=toggleSound;$('camera-button').onclick=changeCamera;$('recover').onclick=function(){if(!game)return;resume();if(game.phase==='race')game.players.forEach(function(c){M.rescue(game,c.playerIndex);});};
  document.addEventListener('click',function(event){var t=event.target.closest('[data-track],[data-players]');if(!t||!game||game.phase!=='garage')return;if(t.hasAttribute('data-track'))M.setTrack(game,t.dataset.track);else{manualPlayers=true;M.setPlayers(game,Number(t.dataset.players));}cardRevision='';menu();});
  document.addEventListener('keydown',function(event){if(event.repeat)return;var code=event.key;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Enter',' ','Tab'].indexOf(code)>=0)event.preventDefault();key(code,true);});document.addEventListener('keyup',function(event){key(event.key,false);});root.addEventListener('blur',function(){backgroundResumeRequested=false;release();if(game&&(game.phase==='race'||game.phase==='countdown'))pause('background');});
  document.addEventListener('visibilitychange',function(){visible=!document.hidden;release();lastTime=0;root.cancelAnimationFrame(frame);if(!visible)pause('background');else{requestBackgroundResume();if(!disposed)frame=root.requestAnimationFrame(animate);}publish();});root.addEventListener('focus',requestBackgroundResume);root.addEventListener('pagehide',dispose);root.addEventListener('resize',resize);
  $('road').addEventListener('webglcontextlost',function(event){event.preventDefault();contextLost=true;pause('graphics');});$('road').addEventListener('webglcontextrestored',function(){contextLost=false;lastTime=0;if(pauseReason==='graphics')resume();});
  updateRoom(info);roomTimer=root.setInterval(function(){if(disposed)return;renderUi(performance.now());publish();},200);
  try{var seed=Date.now()>>>0;if(root.crypto&&root.crypto.getRandomValues){var values=new Uint32Array(1);root.crypto.getRandomValues(values);seed=values[0];}if(typeof root.__USED_CAR_SEED==='number')seed=root.__USED_CAR_SEED;game=M.create({seed:seed,playerCount:1,trackId:'harbor',laps:3});try{muted=localStorage.getItem('used-car-muted')==='true';}catch(_){}renderer=new root.UsedCarRenderer($('road'),{language:english?'en':'zh'});if(renderer.failed)throw new Error(renderer.error);sound=new root.UsedCarAudio();sound.muted=muted;resize();latest=getInputs();menu();if(!renderer.render(game,0))throw new Error(renderer.error||'3D render failed');renderUi(performance.now());$('startup').hidden=true;publish();if(visible)frame=root.requestAnimationFrame(animate);}catch(error){fail(error);}
})(window);
