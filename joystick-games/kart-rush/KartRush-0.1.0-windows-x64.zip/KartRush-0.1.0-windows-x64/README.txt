Kart Rush
Windows 10 1903+ / Windows 11 x64. Requires Microsoft Edge WebView2 Runtime.
Run PureTVGame.exe. The Web folder and game.json must remain beside it.
The game uses the pureTV Wi-Fi controller on TCP 63485 and DNS-SD _puretv._tcp.
Allow this application on your private network when Windows Firewall asks.
Runtime download: https://developer.microsoft.com/microsoft-edge/webview2/
Unsigned community build. See bundled upstream notices.
